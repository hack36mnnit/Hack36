<!DOCTYPE html>
<html>
<head>
	<title>Ticket Generated</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	 <link href="http://allfont.net/allfont.css?fonts=lane-narrow" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div id="container">
	<div id="header">
		<div id="headlogo">
			<img src="renaissance.png">
		</div>
		<div id="summit">
			<p><b>An Entrepreneurship Summit</b></p>
		</div>
	</div>
	<div id="userinfo">
		<div id="details">
			<ul id="mainul">
				<li><h5>Renaissance ID: RENKI5124</h5></li>
				<li><h1>Kishan Patel</h1></li>
				<li><h4>Motilal Nehru National Insitute of Technology</h4></li>
				<li><h4>Allahabad, Uttar Pradesh</h4></li>
				<br>
				<li><h4>coolsandyman@gmail.com</h4></li>
				<li><h3>Registered for: </h3>
					<ul>
						<li>Renaissance</li>
						<li>Workshop</li>
					</ul>
				</li>
			</ul>
		</div>
		<div id="qrcode">
			<iframe src="kishanji.svg"></iframe>
		</div>
		<p><i>Note: Do not tamper this area.</i></p>
	</div>
	<div class="invoice-box">
        <table cellpadding="0" cellspacing="0">
            
            <tr class="heading">
                <td>
                    Payment Method
                </td>
                
                <td>
                    Transaction #
                </td>
            </tr>
            
            <tr class="details">
                <td>
                    Online Portal
                </td>
                
                <td>
                    123156AS651
                </td>
            </tr>
            
            <tr class="heading">
                <td>
                    Registered For
                </td>
                
                <td>
                    Fees
                </td>
            </tr>
            
            <tr class="item">
                <td>
                    Renaissance
                </td>
                
                <td>
                    &#8377; 500
                </td>
            </tr>
            
            <tr class="item">
                <td>
                    Workshop
                </td>
                
                <td>
                    &#8377; 300
                </td>
            </tr>
            
            <tr class="total">
                <td></td>
                
                <td>
                   Total: &#8377; 500
                </td>
            </tr>
        </table>
    </div>
	<div id="footer">
		<div id="backgroundimg"></div>
		<p><b>Terms and Conditions: </b>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
		
	</div>
</div>
</body>
</html>